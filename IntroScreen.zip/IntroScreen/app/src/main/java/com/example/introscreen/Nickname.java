package com.example.introscreen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Nickname extends AppCompatActivity {
    public static String thisNick = "";
    public static boolean newUserNeeded = false;
    private String[] existingUsers = {""};
    private EditText usernameInput;
    private Nickname outerClass = this;
    private boolean newName(String str)
    {
        for(String s : existingUsers) if(s.equals(str)) return false;
        return true; // Default return value
    }

    class ContinueListener implements View.OnClickListener
    {
        @Override
        public void onClick(View v) {
            usernameInput = findViewById(R.id.nickEntry);
            String code = usernameInput.getText().toString();
            if(code == null || code.length() == 0) return; // Do nothing for empty string
            if(code.length() > 15)
            {
                Toast.makeText(getApplicationContext(), "Name too long!", Toast.LENGTH_SHORT).show();
                return;
            }
            if(newName(code)) {
                newUserNeeded = true;
                // ADD THE NEW USER TO DATABASE!
            }
            thisNick = code;
            startActivity(new Intent(outerClass, Scavenger.class));
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting_nickname);
        Button usernameActivity = findViewById(R.id.continue2);
        usernameActivity.setOnClickListener(new ContinueListener());
    }
}
