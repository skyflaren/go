package com.example.introscreen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    public static int thisID;
    private MainActivity outerClass = this;
    private int[] validIDs = {65536, 72854, 12345, 89745}; // Should be initialized via the database. Initialized with arbitrary 5 digit numbers for now.
    private EditText nCodeInput;

    private boolean isValid(String str)
    {
        try {
            int currentID = Integer.parseInt(str);
            for(int i : validIDs) if(i == currentID) return true;
        }
        catch(Exception e) { return false; }
        return false; // Default return value
    }

    class ContinueListener implements View.OnClickListener
    {
        @Override
        public void onClick(View v) {
            nCodeInput = findViewById(R.id.codeInput);
            String code = nCodeInput.getText().toString();
            if(isValid(code)) {
                thisID = Integer.parseInt(code);
                startActivity(new Intent(outerClass, Nickname.class));
            } else Toast.makeText(getApplicationContext(), "Invalid Code!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button usernameActivity = findViewById(R.id.continue1);
        usernameActivity.setOnClickListener(new ContinueListener());
    }
}
