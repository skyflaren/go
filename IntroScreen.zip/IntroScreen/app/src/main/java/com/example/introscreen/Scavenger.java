package com.example.introscreen;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.util.ArrayList;

public class Scavenger extends AppCompatActivity implements OnMapReadyCallback {
    private TextView name; // usernameFill
    private TextView frac; // clueFraction
    private TextView time; // timer
    private Location currentLocation;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 101;
    private ArrayList<User> leaderboard;
    private ArrayList<Objective> tasks;
    private Scavenger outerClass = this;
    private int thisUser;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scavenger_layout);

        tasks = getGenericTasks();
        leaderboard = getUsers();
        int size = tasks.size();
        if(Nickname.newUserNeeded) createNewUser();
        for(User u: leaderboard) {
            u.questionAnswered = new boolean[size];
            if(u.name.equals(Nickname.thisNick)) thisUser = leaderboard.indexOf(u);
        }
        name = findViewById(R.id.usernameFill);
        name.setText(Nickname.thisNick);
        frac = findViewById(R.id.clueFraction);
        time = findViewById(R.id.timer);
        int cnt = 0;
        for(boolean b: leaderboard.get(thisUser).questionAnswered) if(b) cnt++;
        frac.setText(cnt + " / " + tasks.size());
        time.setText(leaderboard.get(thisUser).timeAsString());
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fetchLastLocation();

        ImageButton clueMenu = findViewById(R.id.listClues);
        clueMenu.setOnClickListener(new ClueListener());
    }
    class ClueListener implements View.OnClickListener
    {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(outerClass, ClueList.class));
        }
    }
    private void createNewUser()
    {
        User u = new User();
        u.name = Nickname.thisNick;
        u.questionAnswered = new boolean[tasks.size()];
        u.startTime = u.recentSubmitTime = System.currentTimeMillis();
        leaderboard.add(u);
        // ADD TO DATABASE!
    }
    private void fetchLastLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[]
                    {Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location != null){
                    currentLocation = location;
                    Toast.makeText(getApplicationContext(),currentLocation.getLatitude() +""+currentLocation.getLongitude(),Toast.LENGTH_SHORT).show();
                    SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.google_map);
                    supportMapFragment.getMapAsync(outerClass);
                }
            }
        });

        update();
    }
    /* Updates the database and variables for the current user in real time. */

    private void update()
    {
        if(currentLocation == null) return;
        leaderboard.get(thisUser).lat = currentLocation.getLatitude();
        leaderboard.get(thisUser).lon = currentLocation.getLongitude();

        ArrayList<Integer> newClues = leaderboard.get(thisUser).fetchTasksInRange(tasks);
        boolean newClueFound = false;
        for(int i: newClues)
        {
            if(!leaderboard.get(thisUser).questionAnswered[i]) newClueFound = true;
            leaderboard.get(thisUser).questionAnswered[i] = true;
        }
        if(newClueFound)
        {
            Toast.makeText(getApplicationContext(), "Found a new Clue!", Toast.LENGTH_SHORT).show();
            leaderboard.get(thisUser).recentSubmitTime = System.currentTimeMillis();
        }
        int cnt = 0;
        for(boolean b: leaderboard.get(thisUser).questionAnswered) if(b) cnt++;
        frac.setText(cnt + " / " + tasks.size());
        time.setText(leaderboard.get(thisUser).timeAsString());


        // UPDATE DATABASE TODO
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        LatLng latLng = new LatLng(currentLocation.getLatitude(),currentLocation.getLongitude());
        MarkerOptions markerOptions = new MarkerOptions().position(latLng).title("I am Here");
        googleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,5));
        googleMap.addMarker(markerOptions);
        try {
            // Customise the styling of the base map using a JSON object defined
            // in a raw resource file.
             boolean success = googleMap.setMapStyle(
                    MapStyleOptions.loadRawResourceStyle(
                            getApplicationContext(), R.raw.style));

            if (!success) {
                Log.e("MainActivity", "Style parsing failed.");
            }
        } catch (Resources.NotFoundException e) {
            Log.e("MainActivity", "Can't find style. Error: ", e);
        }
        update();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case REQUEST_CODE:
                if(grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    fetchLastLocation();
                }
                break;
        }
    }
    private ArrayList<Objective> getGenericTasks()
    {
        // THIS SHOULD GET FROM DATABASE
        Objective o = new Objective("Get", "Do something else for it to work", 0, 0);
        ArrayList<Objective> ret = new ArrayList<>();
        ret.add(o);
        return ret;
        //throw new NotImplementedError();
    }
    private ArrayList<User> getUsers()
    {
        // THIS SHOULD GET FROM DATABASE
        return new ArrayList<User>();
        //throw new NotImplementedError();
    }
    public class ClueList extends AppCompatActivity {
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

        }
    }
}
class User implements Comparable<User>
{
    public String name;
    public boolean[] questionAnswered;
    public long startTime, recentSubmitTime;
    public int totPoints;
    public double lat, lon;
    @Override
    public int compareTo(User o) {
        return totPoints - totPoints;
    }
    public ArrayList<Integer> fetchTasksInRange(ArrayList<Objective> tasks)
    {
        ArrayList<Integer> ret = new ArrayList<>();
        boolean quit = false;
        for(int i = 0; i < tasks.size(); i++)
        {
            if(quit) break;
            if(!questionAnswered[i]) quit = true; // Exits the loop after the first unanswered question.
            Objective t = tasks.get(i);
            if(Objective.dist(Objective.convertLatToMetres(t.lat, t.lon), Objective.convertLonToMetres(t.lat, t.lon), Objective.convertLatToMetres(lat, lon), Objective.convertLonToMetres(lat, lon)) <= Objective.PICKUP_RADIUS)
                ret.add(i);
        }
        return ret;
    }
    public String timeAsString()
    {
        long seconds = recentSubmitTime - startTime;
        seconds /= 1000;
        long minutes = seconds / 60;
        seconds %= 60;
        String min = (minutes < 10? "0": "") + minutes;
        String sec = (seconds < 10? "0": "") + seconds;
        return min + ":" + sec;
    }
}
class Objective {

    public static final double PICKUP_RADIUS = 100;
    public static double convertLatToMetres(double lat, double lon) { return lat * 111320; }
    public static double convertLonToMetres(double lat, double lon) { return lon * 40075 * Math.cos(lat) / 0.36; }
    public static double dist(double x1, double y1, double x2, double y2) { return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)); }
    public String taskName;
    public double lat, lon;
    public String clue;

    public Objective(String tn, String cl, double la, double lo)
    {
        taskName = tn;
        lat = la;
        lon = lo;
        clue = cl;
    }
}
