package com.example.introscreen

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class Nickname:AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.setting_nickname)
    }

}